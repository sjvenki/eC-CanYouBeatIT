using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionManager : MonoBehaviour
{
    private void Awake() => MessageBus.SubscribeTo<CollisionMessage>(OnHitPlayer);

    private void OnHitPlayer(CollisionMessage message)
    {
        Debug.Log("Here " + message.Entity.ToString());
        throw new NotImplementedException();
    }

}
