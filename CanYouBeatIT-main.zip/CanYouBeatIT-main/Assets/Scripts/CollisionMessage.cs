﻿internal class CollisionMessage
{
    private string entity;
    public CollisionMessage(string entity)
    {
        this.entity = entity;
    }

    public string Entity { get { return entity; } }
}