using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class PlayerBehaviour : MonoBehaviour
{
    public float velocity; // To be linked to CoreLib

    // Start is called before the first frame update
    void Start()
    {
        velocity = 5.0f;
    }

    // Update is called once per frame
    void Update()
    {
        float moveX = Input.GetAxis("Horizontal");
        float moveY = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(moveX, moveY, 0f) * velocity * Time.deltaTime;
        transform.Translate(movement);

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Terrain"))
        {
            Vector3Int tilePosition = collision.gameObject.GetComponent<Tilemap>().WorldToCell(collision.contacts[0].point);
            string tileName = collision.gameObject.GetComponent<Tilemap>().GetTile(tilePosition).name;
            Debug.Log("Player collision with + " + tileName  + " at " + tilePosition);

            // Publish collision message
            MessageBus.Publish(new CollisionMessage(tileName));
        }
        else if (collision.gameObject.CompareTag("Interactable"))
        {
            Vector3Int tilePosition = collision.gameObject.GetComponent<Tilemap>().WorldToCell(collision.contacts[0].point);
            string tileName = collision.gameObject.GetComponent<Tilemap>().GetTile(tilePosition).name;
            Debug.Log("Player collision with + " + tileName + " at " + tilePosition);

            // Publish collision message
            MessageBus.Publish(new CollisionMessage(tileName));
        }
    }
}
