using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class MessageBus
{
    private static Dictionary<Type, List<Delegate>> _subscribers = new();

    // Subscribing
    public static void SubscribeTo<T>(Action<T> del)
    {
        var type = typeof(T);
        if (!_subscribers.ContainsKey(type))
        {
            _subscribers.Add(type, new List<Delegate>());
        }

        _subscribers[type].Add(del);

        Debug.Log(del.Target + " subscribed to type " + typeof(T));
    }

    // Publishing
    public static void Publish<T>(T messageData)
    {
        Debug.Log("Published message of type " + typeof(T));
        var type = typeof(T);
        if (!_subscribers.ContainsKey(type))
        {
            return;
        }

        foreach (var del in _subscribers[type])
        {
            del.DynamicInvoke(messageData);
        }
    }

}
